//
//  DynamicChangeCode.h
//  jht
//
//  Created by 泽鹏邵 on 16/8/17.
//  Copyright © 2016年 dhgh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DynamicChangeCode : NSObject
//通过服务器动态修改程序bug
+(void) loadURLConnectionCompletion;
@end
